import random
def tush():
    a=0.0
    b=16.0           #this is the length or end of the thread
    i = 0
    while (b-a)>1:
        p = random.randint(0,1)
        if p == 0:
            a = a + (b-a)/2
        else:
            b = b - (b-a)/2
    return (a+b)//2
a = 0
b=0
c=0
d=0
e=0
f=0
g=0
h=0
i=0
j=0
for k in range(100000):
    p = int(tush())
    if p ==1:
        a =a +1
    elif p==2:
        b=b+1
    elif p==3:
        c=c+1
    elif p==4:
        d=d+1
    elif p==5:
        e=e+1
    elif p==6:
        f=f+1
    elif p==7:
        g=g+1
    elif p==8:
        h=h+1
    elif p==9:
        i = i+1
    elif p==10:
        j=j+1
print(a,b,c,d,e,f,g,h,i,j)
