import random
def radd():
    S = [1,2,3,4,5,6,7,8,9,10]
    while(len(S)>1):
        for x in S:
            i = random.randint(0,1)
            if i == 0:
                S.remove(x)
    return S[0]
a = 0
b=0
c=0
d=0
e=0
f=0
g=0
h=0
i=0
j=0
for k in range(1000):
    p = radd()
    if p ==1:
        a =a +1
    elif p==2:
        b=b+1
    elif p==3:
        c=c+1
    elif p==4:
        d=d+1
    elif p==5:
        e=e+1
    elif p==6:
        f=f+1
    elif p==7:
        g=g+1
    elif p==8:
        h=h+1
    elif p==9:
        i = i+1
    elif p==10:
        j=j+1
print(a,b,c,d,e,f,g,h,i,j)
