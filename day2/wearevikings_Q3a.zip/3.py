import random

def equalProbGenerator():
  valid = False
  while not valid:
    # Example:
    # 9  = (1001)
    # 10 = (1010)
    seq = [random.randint(0, 1) for _ in range(4)]
    # print(seq)
    value = sum([seq[3-i]*pow(2,i) for i in range(4)])
    # print(val)
    valid = value>=1 and value<=10
  return value
